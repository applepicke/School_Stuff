﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Generics
{
    public class Point<T>
    {
        public T X
        {
            get;
            set;
        }

        public T Y
        {
            get;
            set;
        }

        public int Z
        {
            get;
            set;
        }

        public Point()
        {
            Z = 0;
        }

        public void Display()
        {
            Console.Out.WriteLine(X + " : " + Y + " : " + Z);

            Console.Out.WriteLine();
            Console.Out.WriteLine();
            Console.Out.WriteLine();
            Console.Out.WriteLine();
        }
    }
}
