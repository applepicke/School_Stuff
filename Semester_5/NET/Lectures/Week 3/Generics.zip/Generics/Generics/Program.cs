﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Generics
{
    class Program
    {
        static void Main(string[] args)
        {
            // lets plot some points on a grid
            Point<int> p1 = new Point<int>();
            p1.X = 1;
            p1.Y = 82;
            p1.Z = 222;
            //p1.Y = 2.0; 2.0 is not an int, so it will not work

            p1.Display();





            Point<double> p2 = new Point<double>();
            p2.X = 1.0453;
            p2.Y = 4.9234;
            p2.Z = 32;

            p2.Display();




            Point<string> p3 = new Point<string>();
            p3.X = "This is point 1";
            p3.Y = "This is not point 2";
            p3.Z = 55;

            //p3.Y = 2.0; 2.0 is not a string, so it will not work

            p3.Display();




            Console.In.ReadLine();
        }
    }
}
