﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;

namespace CSharp_XML
{
    // create a custom fileinfo object as we can not instantiate a new System.IO.FileInfo object
    class MyFileInfo
    {
        public string Path
        {
            get;
            set;
        }

        public string Name
        {
            get;
            set;
        }

        public long Length
        {
            get;
            set;
        }
    }
            
    /// <summary>
    /// Application entry
    /// </summary>
    class Program
    {
        // hold the list of files to be output
        static List<FileInfo> outputInformationList = new List<FileInfo>();

        // hold the list of files read from the system
        static List<MyFileInfo> inputInformationList = new List<MyFileInfo>();

        /// <summary>
        /// Application entry point
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            // get the files
            Crawl(System.Environment.CurrentDirectory);

            // write the files as XML
            WriteXml();

            // output the values that were written
            foreach (FileInfo fi in outputInformationList)
                OutputFileInfo(fi);

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            // read the xml file and store the result
            ReadXml();

            // output the reader results
            foreach (MyFileInfo fi in inputInformationList)
                OutputMyFileInfo(fi);
        }

        /// <summary>
        /// Method, writes an xml file that contains the other files in the directory
        /// </summary>
        static void WriteXml()
        {
            // the using keyword provides a limited context to the object created
            // when the code is finished executing and falls out the bottom of the using{} stack
            // IDisposable's Dispose method is automatically used
            using (XmlWriter writer = XmlWriter.Create("files.xml"))
            {
                writer.WriteStartDocument();
                writer.WriteStartElement("files");

                foreach (FileInfo fileInfo in outputInformationList)
                {
                    writer.WriteStartElement("file");

                    writer.WriteElementString("path", fileInfo.FullName);
                    writer.WriteElementString("name", fileInfo.Name);
                    writer.WriteElementString("length", fileInfo.Length.ToString());

                    writer.WriteEndElement();
                }

                writer.WriteEndElement();
                writer.WriteEndDocument();
                writer.Close();
            }
        }

        /// <summary>
        /// Method, reads the xml file saved to the file system
        /// </summary>
        static void ReadXml()
        {
            // the using keyword provides a limited context to the object created
            // when the code is finished executing and falls out the bottom of the using{} stack
            // IDisposable's Dispose method is automatically used
            using (XmlReader reader = XmlReader.Create("files.xml"))
            {
                while (reader.Read())
                {
                    if (reader.NodeType == XmlNodeType.Element)
                    {
                        if (reader.Name == "files")
                            continue;

                        if (reader.Name == "file")
                        {

                            reader.ReadStartElement();

                            MyFileInfo myFileInfo = new MyFileInfo();
                            myFileInfo.Path = reader.ReadElementString("path");
                            myFileInfo.Name = reader.ReadElementString("name");
                            myFileInfo.Length = Convert.ToInt64(reader.ReadElementString("length"));
                            inputInformationList.Add(myFileInfo);

                            reader.ReadEndElement();
                        }
                    }
                }

                reader.Close();
            }
        }

        /// <summary>
        /// Mathod, Get all the files in the path
        /// </summary>
        /// <param name="path"></param>
        static void Crawl(string path)
        {
            string[] directories = Directory.GetDirectories(path);

            foreach (string directory in directories)
                Crawl(directory);

            string[] files = Directory.GetFiles(path);

            foreach (string file in files)
                outputInformationList.Add(new FileInfo(file));
        }

        /// <summary>
        /// Method, output a file info object
        /// </summary>
        /// <param name="fi"></param>
        static void OutputFileInfo(FileInfo fi)
        {
            Console.Out.WriteLine("{0}\t\t{1}\t\t{2}", fi.Name, fi.Directory.Name, fi.Length);
        }

        /// <summary>
        /// Method, output our custom file info object
        /// </summary>
        /// <param name="fi"></param>
        static void OutputMyFileInfo(MyFileInfo fi)
        {
            Console.Out.WriteLine("{0}\t\t{1}\t\t{2}", fi.Name, fi.Path, fi.Length);
        }
    }
}
