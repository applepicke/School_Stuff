﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CreateSessionInformation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.errorLabel.Text = string.Empty;
    }

    protected void sessionSubtmitButton_OnClick(object sender, EventArgs e)
    {
        Session["FirstName"] = sessionFirstNameTextBox.Text;
        Session["LastName"] = sessionLastNameTextBox.Text;

        errorLabel.Text = "Session State Created";
    }

    protected void subtmitButton_OnClick(object sender, EventArgs e)
    {
        Application["FirstName"] = firstNameTextBox.Text;
        Application["LastName"] = lastNameTextBox.Text;

        errorLabel.Text = "Application State Created";
    }
}