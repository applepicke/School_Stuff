﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ViewSessionInformation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["FirstName"] != null)
            this.sessionFirstNameLabel.Text = Session["FirstName"].ToString();

        if (Session["LastName"] != null)
            this.sessionLastNameLabel.Text = Session["LastName"].ToString();

        if (Application["FirstName"] != null)
            this.firstNameLabel.Text = Application["FirstName"].ToString();

        if (Application["LastName"] != null)
            this.lastNameLabel.Text = Application["LastName"].ToString();
    }
}