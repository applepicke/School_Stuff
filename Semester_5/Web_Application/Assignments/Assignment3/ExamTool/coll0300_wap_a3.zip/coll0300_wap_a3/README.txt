*******************************************
           WILLY's EXAM TOOL README
*******************************************
If you are reading this, it means that you have purchased the great and wonderful
exam tool! There are a few things you need to know before you get started, so 
read carefully.

First off, this application was build using PrimeFaces 3.2. Why does that matter? Well, 
it just does.

In order to get yourself set up, you first need to create a Derby database named "wap_a3". 
This database will be used to store and retrieve exam information.

Once you have your database set up, you will want to run the "wap_a3_create_tables" sql script,
followed by the "wap_a3_insert_into_tables". The first script creates the database table, while
the second inserts the exams you will be writing. 

You should be all set to run the application, and start doing some great assessing of your own self
worth. Congratulations!