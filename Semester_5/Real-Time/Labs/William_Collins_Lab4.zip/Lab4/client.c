/*
 * File Name:     client.c
 * version:       1.0
 * Author:        William Collins
 * Date:          1/30/2012
 * Assignment:    Lab #4
 * Course:        Real Time Programming
 * Code:          CST8244
 * Professor:     Saif Terai
 * Due Date:      2/2/2012
 * Submission
 * Type:          Email Submission
 * Destination
 * Address:       terais@algonquincollege.com
 * Subject Line:  CST 8244, F11, Lab 4
 * Description:	  Sends an x and y value to the server, and recieves a product in response
 */
#include <stdlib.h>
#include <stdio.h>
#include <sys/iofunc.h>
#include <sys/dispatch.h>
#include "prod.h"

/********************************************************************************************
 * Function Name        main()
 * Version              1.0
 * Author               William Collins
 * Purpose
 * Inputs               command line arguments
 * Outputs              Returns an integer, '0' on successful completion, '1' if an error
 *                      occurred.
 *********************************************************************************************/
int main(int argc, char *argv[]) {
	int coid;			//Connection ID
	struct prod msg;	//Message to hold variables and product
	int status;

	//Assign default values
	msg.x = 6;
	msg.y = 9;

	//Make sure there are the correct number of arguments
	if( argc > 3 ) {
		printf("Too many arguments\n");
		exit(EXIT_FAILURE);
	}

	//If they exist, use command line x and y
	if (argc == 3)
	{
		msg.x = atoi(argv[1]);
		msg.y = atoi(argv[2]);
	}

	//Connect to the server
	printf("Connecting to server %s...", SERVER_NAME);
	coid = name_open(SERVER_NAME, 0);

	//Determine if the connection was successful
	if(-1 == coid) {   //was there an error attaching to server?
		perror("ConnectAttach"); //look up error code and print
		exit(EXIT_FAILURE);
	} else {
		printf( "Successfully connected.\n");
	}

	//Send the message to server and get the reply
	status = MsgSend(coid, &msg, sizeof msg, &msg, sizeof msg);

	//Check for communication errors
	if(-1 == status) {   //was there an error sending to server?
		perror("MsgSend");
		exit(EXIT_FAILURE);
	} else {
		printf( "The product of %d and %d is %d\n", msg.x, msg.y, msg.product );
	};

	//Make sure to close resources
	name_close(coid);
	return EXIT_SUCCESS;

}
