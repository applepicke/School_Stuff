/* arith.h
 * Algonquin College
 * CST 8244
 * Assignment 2
 * Winter 2012
*/

typedef struct {
    double operand1;
    double operand2;
    double sum;
    double difference;
    double product;
    double quotient;
} arith;

#define NAME "array"
#define SERVER_NAME "cool_server"
#define BEGIN_PULSE 3
#define SUM_PULSE 2
#define DIFF_PULSE 1

/* eof: arith.h */
